USE [PrestigeCars];
GO

/*
===============================================================================
  PROCEDURE:     MotorSales.usp_normalizeStock
===============================================================================
  AUTHOR(S):     Nageem Saira  
                 Corey Almonte  
  CREATED:       2025-05-18
  VERSION:       3.0

  DESCRIPTION:
    Alters [MotorSales].[Stock] to conform to the UML-compliant schema:
      - Uses only professor-defined UDTs
      - Enforces NOT NULL constraints
      - Adds DEFAULT and CHECK constraints
      - Inserts data from [Data].[FlattenedTable] (no WHERE clause)
      - Adds unique index on StockCode

  MODIFICATION HISTORY:
  ------------------------------------------------------------------------------
  DATE        AUTHOR(S)         DESCRIPTION
  ----------  ----------------  -----------------------------------------------
  2025-05-09  Nageem Saira       Initial creation based on UML diagram  
  2025-05-17  Nageem Saira       Underwent professor code review  
  2025-05-18  Nageem Saira       Split from usp_normalizePair2 into this version  
===============================================================================
*/

CREATE OR ALTER PROCEDURE MotorSales.usp_normalizeStock
AS
BEGIN
    SET NOCOUNT ON;

    --------------------------------------------------------------------------------
    -- ALTER TABLE MotorSales.Stock
    --------------------------------------------------------------------------------
    ALTER TABLE MotorSales.Stock
    ALTER COLUMN StockCode UDT_StockCode NOT NULL;
    
    ALTER TABLE MotorSales.Stock
    ALTER COLUMN IsRHD UDT_IsRHD NOT NULL;
    
    ALTER TABLE MotorSales.Stock
    ALTER COLUMN Color UDT_Color NOT NULL;
    
    ALTER TABLE MotorSales.Stock
    ALTER COLUMN DateBought UDT_DateYYYYMMDD NOT NULL;
    
    ALTER TABLE MotorSales.Stock
    ALTER COLUMN TimeBought UDT_TimeBought NOT NULL;
    
    ALTER TABLE MotorSales.Stock
    ALTER COLUMN Cost UDT_Cost NOT NULL;
    
    ALTER TABLE MotorSales.Stock
    ALTER COLUMN RepairsCost UDT_Cost NOT NULL;
    
    ALTER TABLE MotorSales.Stock
    ALTER COLUMN PartsCost UDT_Cost NOT NULL;
    
    ALTER TABLE MotorSales.Stock
    ALTER COLUMN TransportationCost UDT_Cost NOT NULL;
    
    ALTER TABLE MotorSales.Stock
    ALTER COLUMN ModelID UDT_ModelID NOT NULL;

    ALTER TABLE MotorSales.Stock
    ADD CONSTRAINT DF_StockCode_Default DEFAULT 'UNALLOCATED' FOR StockCode,
        CONSTRAINT DF_Color_Default DEFAULT 'UNSPECIFIED' FOR Color,
        CONSTRAINT DF_Flag_Default DEFAULT 0 FOR IsRHD,
        CONSTRAINT DF_DateBought_Default DEFAULT '1900-01-01' FOR DateBought,
        CONSTRAINT DF_TimeBought_Default DEFAULT '00:00:00.000000' FOR TimeBought,
        CONSTRAINT DF_Cost_Default DEFAULT 0.00 FOR Cost,
        CONSTRAINT DF_RepairsCost_Default DEFAULT 0.00 FOR RepairsCost,
        CONSTRAINT DF_PartsCost_Default DEFAULT 0.00 FOR PartsCost,
        CONSTRAINT DF_TransportationCost_Default DEFAULT 0.00 FOR TransportationCost,
        CONSTRAINT CHK_Cost_NonNegative CHECK (Cost >= 0),
        CONSTRAINT CHK_RepairsCost_NonNegative CHECK (RepairsCost >= 0),
        CONSTRAINT CHK_PartsCost_NonNegative CHECK (PartsCost >= 0),
        CONSTRAINT CHK_TransportCost_NonNegative CHECK (TransportationCost >= 0);

    --------------------------------------------------------------------------------
    -- CREATE UNIQUE NONCLUSTERED INDEX on StockCode
    --------------------------------------------------------------------------------
    IF NOT EXISTS (
        SELECT * FROM sys.indexes 
        WHERE name = 'IX_Stock_StockCode'
          AND object_id = OBJECT_ID('MotorSales.Stock')
    )
    BEGIN
        CREATE UNIQUE NONCLUSTERED INDEX IX_Stock_StockCode
        ON MotorSales.Stock (StockCode);
    END;

    --------------------------------------------------------------------------------
    -- INSERT DATA INTO MotorSales.Stock
    --------------------------------------------------------------------------------
    INSERT INTO MotorSales.Stock (
        StockCode, IsRHD, Color, DateBought, TimeBought,
        Cost, RepairsCost, PartsCost, TransportationCost, ModelID
    )
    SELECT DISTINCT
        f.StockCode,
        f.IsRHD,
        f.Color,
        f.DateBought,
        f.TimeBought,
        f.Cost,
        f.RepairsCost,
        f.PartsCost,
        f.TransportInCost,
        f.ModelID
    FROM Data.FlattenedTable f;

END;
GO


USE [PrestigeCars];
GO

/*
===============================================================================
  PROCEDURE:     MotorSales.usp_normalizeBuyerFeedback
===============================================================================
  AUTHOR(S):    Nageem Saira 
                 Corey Almonte  
  CREATED:       2025-05-18
  VERSION:       3.0

  DESCRIPTION:
    Creates and populates [MotorSales].[BuyerFeedback] using professor-defined UDTs.
    Ensures:
      - PRIMARY KEY on StockID
      - DEFAULT constraint on Comment
      - Insertion of all available rows (no WHERE clause)
      - Adds unique index on StockID for safety (though already PK)

  MODIFICATION HISTORY:
  ------------------------------------------------------------------------------
  DATE        AUTHOR(S)         DESCRIPTION
  ----------  ----------------  -----------------------------------------------
  2025-05-09  Nageem Saira       Initial creation based on UML diagram  
  2025-05-17  Nageem Saira       Underwent professor code review  
  2025-05-18  Nageem Saira       Split from usp_normalizePair2 into this version  
===============================================================================
*/

CREATE OR ALTER PROCEDURE MotorSales.usp_normalizeBuyerFeedback
AS
BEGIN
    SET NOCOUNT ON;

    --------------------------------------------------------------------------------
    -- CREATE TABLE MotorSales.BuyerFeedback
    --------------------------------------------------------------------------------
    IF NOT EXISTS (
        SELECT * FROM sys.tables
        WHERE name = 'BuyerFeedback' AND schema_id = SCHEMA_ID('MotorSales')
    )
    BEGIN
        CREATE TABLE MotorSales.BuyerFeedback (
            StockID  UDT_StockID PRIMARY KEY,
            Comment  UDT_Comment CONSTRAINT DF_Comment_Default DEFAULT ''
        );
    END;

    --------------------------------------------------------------------------------
    -- INSERT DATA INTO MotorSales.BuyerFeedback
    --------------------------------------------------------------------------------
    INSERT INTO MotorSales.BuyerFeedback (
        StockID, Comment
    )
    SELECT DISTINCT
        st.StockID,
        LEFT(f.BuyerComments, 255)
    FROM Data.FlattenedTable f
    JOIN MotorSales.Stock st ON f.StockCode = st.StockCode;

END;
GO