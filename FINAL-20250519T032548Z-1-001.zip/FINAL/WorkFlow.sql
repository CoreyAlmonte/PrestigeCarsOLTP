CREATE SCHEMA Process
GO
CREATE TABLE Process.WorkFlowSteps(
    WorkFlowStepKey INT IDENTITY(1,1),
    WorkFlowStepDescription NVARCHAR (100) NOT NULL,
    WorkFlowStepTableRowCount INT NOT NULL DEFAULT (0),
    StartingDateTime DATETIME2(7) NOT NULL DEFAULT (SYSDATETIME ()),
    EndingDateTime DATETIME2(7) NOT NULL DEFAULT (SYSDATETIME ()),
    ClassTime CHAR (5) NOT NULL DEFAULT ('10:45'),
    UserAuthorizationKey INT NOT NULL 
    
)

GO
CREATE PROCEDURE Process.TrackWorkFlow
@StartTime DATETIME2,
@WorkFlowDescription NVARCHAR(100),
@WorkFlowStepTableRowCount INT,
@UserAuthorizationKey INT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Process.WorkflowSteps (
        WorkFlowStepDescription,
        WorkFlowStepTableRowCount,
        StartingDateTime,
        EndingDateTime,
        ClassTime,
        UserAuthorizationKey
    )
    VALUES (
        @WorkFlowDescription,
        @WorkFlowStepTableRowCount,
        @StartTime,
        SYSDATETIME(),
        '10:45',
        @UserAuthorizationKey
    );
END;
