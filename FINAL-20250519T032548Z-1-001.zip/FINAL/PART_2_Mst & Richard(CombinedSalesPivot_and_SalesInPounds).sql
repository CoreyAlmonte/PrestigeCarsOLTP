USE PrestigeCars;
GO

/*
===============================================================================
  VIEW:         [Output].[vw_CombinedSalesPivot]
===============================================================================
  AUTHOR(S):    MST Rahi, Richard Garnica, Corey Almonte
  CREATED:      2025-05-18
  VERSION:      1.1

  DESCRIPTION:
    Consolidates yearly sales (via Output.fn_getSalesByYear) with 
    PivotTable data and contextual information from SourceData.SalesText.

  DEPENDENCIES:
    - Output.fn_getSalesByYear (inline table-valued function)
    - Data.PivotTable (pivoted sale summary)
    - SourceData.SalesText (commentary and metadata)

  OUTPUT COLUMNS:
    - SalesID, InvoiceNumber, SaleDate, TotalSalePrice, Year
    - Pivot2015, Pivot2016, Pivot2017, Pivot2018
    - MakeName, CountryName

  MODIFICATION HISTORY:
  ------------------------------------------------------------------------------
  DATE        AUTHOR(S)                         DESCRIPTION
  ----------  --------------------------------  ----------------------------------
  2025-05-18  MST Rahi, Richard Garnica, Corey Almonte Final version linked to real tables
===============================================================================
*/
CREATE OR ALTER VIEW [Output].[vw_CombinedSalesPivot]
AS
SELECT
    s.SalesID,
    s.InvoiceNumber,
    s.SaleDate,
    s.TotalSalePrice,
    YEAR(s.SaleDate) AS [Year],
    p.[2015] AS Pivot2015,
    p.[2016] AS Pivot2016,
    p.[2017] AS Pivot2017,
    p.[2018] AS Pivot2018,
    st.MakeName,
    st.CountryName
FROM Output.fn_getSalesByYear(2015) AS s
LEFT JOIN Data.PivotTable AS p
    ON CAST(s.SaleDate AS DATE) = p.SaleDate
LEFT JOIN SourceData.SalesText AS st
    ON s.InvoiceNumber = st.MakeName; -- Adjust JOIN logic if needed
GO

USE PrestigeCars;
GO

/*
===============================================================================
  VIEW:         [Output].[vw_SalesInPounds]
===============================================================================
  AUTHOR(S):    MST Rahi, Richard Garnica, Corey Almonte
  CREATED:      2025-05-18
  VERSION:      1.0

  DESCRIPTION:
    Exposes vehicle sales in GBP (£) from [SourceData].[SalesInPounds]
    for reporting and analysis.

  OUTPUT COLUMNS:
    - MakeName, ModelName, VehicleCost

  MODIFICATION HISTORY:
  ------------------------------------------------------------------------------
  DATE        AUTHOR(S)                         DESCRIPTION
  ----------  --------------------------------  ----------------------------------
  2025-05-18  MST Rahi, Richard Garnica, Corey Almonte  Initial creation
===============================================================================
*/
CREATE OR ALTER VIEW [Output].[vw_SalesInPounds]
AS
SELECT
    MakeName,
    ModelName,
    VehicleCost
FROM SourceData.SalesInPounds;
GO


/*
===============================================================================
  VIEW:         [Output].[vw_YearlySales]
===============================================================================
  AUTHOR(S):    MST Rahi, Richard Garnica, Corey Almonte
  CREATED:      2025-05-18
  VERSION:      1.0

  DESCRIPTION:
    Displays detailed yearly sales records from Reference.YearlySales
    for cross-tabulation and reporting.

  OUTPUT COLUMNS:
    - MakeName, ModelName, CustomerName, CountryName, Cost,
      RepairsCost, PartsCost, TransportInCost, SalePrice, SaleDate
===============================================================================
*/
CREATE OR ALTER VIEW [Output].[vw_YearlySales]
AS
SELECT
    ys.MakeName,
    ys.ModelName,
    ys.CustomerName,
    ys.CountryName,
    ys.Cost,
    ys.RepairsCost,
    ys.PartsCost,
    ys.TransportInCost,
    ys.SalePrice,
    ys.SaleDate
FROM Reference.YearlySales AS ys