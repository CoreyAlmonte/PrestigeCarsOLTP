/*
================================================================================
  PROCEDURES: MotorSales.NormalizeForex
              MotorSales.NormalizeMarketingCat
              MotorSales.NormalizeMarketingInfo
              MotorSales.CreateSpendCapacity
              SalesBudget.NormalizeSalesBudget
              SalesBudget.CreateSalesBudgetArea
              MotorSales.NormalizeSalesCatagory

================================================================================
  AUTHOR:      Ketan Persaud
  DATE:        5/15/2025

  DESCRIPTION: 
    Take tables:
    -Forex
    -MarketingCategory
    -MarketingInformation
    -SalesBudget
    -SalesCategory
    Normalize them into Third Normalized Form

    Create tables SpendCapacity and SalesBudgetArea to remove non-key dependency

    Store these processes as Stored Procedures
  TABLES INCLUDED:
    -Reference.Forex
    -Reference.MarketingCategory
    -Reference.MarketingInformation
    -Reference.SalesBudget
    -Reference.SalesCategory

  PARAMETERS:
  None

  USAGE EXAMPLE:
    EXEC MotorSales.NormalizeForex
    EXEC MotorSales.NormalizeMarketingCat
    EXEC MotorSales.NormalizeMarketingInfo
    EXEC MotorSales.CreateSpendCapacity
    EXEC SalesBudget.NormalizeSalesBudget
    EXEC SalesBudget.CreateSalesBudgetArea
    EXEC MotorSales.NormalizeSalesCatagory

  RESULT:
  Creates and Alter the tables into Third Normalized Form

  MODIFICATIONS:
  DATE        AUTHOR			DESCRIPTION
  ----------  ----------		----------------------------------------------------
  5/15/2025    Ketan Persaud    Normalization
================================================================================
*/


CREATE SCHEMA MotorSales;
GO

CREATE SCHEMA SalesBudget;
GO


-- Normalize Forex
CREATE PROCEDURE MotorSales.NormalizeForex
AS
BEGIN
    SET NOCOUNT ON;
ALTER TABLE Reference.forex
ADD  ForexID Udt.SurrogateKeyInt IDENTITY(1,1); -- create new primary key column

ALTER TABLE Reference.forex
ADD CONSTRAINT PK_ForexID PRIMARY KEY(ForexID);

ALTER TABLE Reference.Forex
ADD CountryISO3 Udt.CountryCode -- renaming columns

ALTER TABLE Reference.Forex
ADD CONSTRAINT DF_Country_Default DEFAULT 'UNSPECIFIED' FOR CountryISO3;

INSERT INTO Reference.Forex (CountryISO3)
SELECT ISOCurrency
FROM Reference.Forex;

ALTER TABLE Reference.Forex
DROP COLUMN ISOCurrency;


END;
GO


-- Normalize MarketingCategory
Create PROCEDURE MotorSales.NormalizeMarketingCat
AS
BEGIN
    SET NOCOUNT ON;
ALTER TABLE Reference.MarketingCategories
ADD  MarketingCategoryID Udt.SurrogateKeyInt IDENTITY(1,1); --create new primary key column

ALTER TABLE Reference.MarketingCategories
ADD CONSTRAINT PK_MarketingCategoryID PRIMARY KEY(ForexID);

ALTER TABLE Reference.MarketingCategories
ADD MakeID Udt.SurrogateKeyInt IDENTITY(1,1); --create new foreign key column

ALTER TABLE Reference.MarketingCategories
ADD CONSTRAINT FK_MakeID FOREIGN KEY (MakeID) REFERENCES Data.Make(MakeID);

END;
GO


-- Normalize MarketingInfor
CREATE PROCEDURE MotorSales.NormalizeMarketingInfo
AS
BEGIN
    SET NOCOUNT ON;
ALTER TABLE Reference.MarketingInformation
ADD  CustomerID Udt.SurrogateKeyInt IDENTITY(1,1); --create new primary and foreign key column

ALTER TABLE Reference.MarketingInformation
ADD CONSTRAINT PK_CustomerID PRIMARY KEY (CustomerID);

ALTER TABLE Reference.MarketingInformation
ADD CONSTRAINT FK_CustomerID FOREIGN KEY (CustomerID) REFERENCES Data.Customer(CustomerID);

ALTER TABLE Reference.MarketingInformation
ADD CustomerName Udt.NameType; -- renaming column

ALTER TABLE Reference.MarketingInformation
ADD CONSTRAINT DF_Name_Default DEFAULT 'UNSPECIFIED' FOR CustomerName;

INSERT INTO Reference.MarketingInformation (CustomerName)
SELECT CUST
FROM Reference.MarketingInformation;

ALTER TABLE Reference.MarketingInformation
DROP COLUMN CUST;

ALTER TABLE Reference.MarketingInformation
ADD CountryISO2 Udt.CountryName; -- renaming column

ALTER TABLE Reference.MarketingInformation
ADD CONSTRAINT DF_CountryCode_ISO2_Default DEFAULT 'ZZ' FOR (CountryISO2);

ALTER TABLE Reference.MarketingInformation
ADD CONSTRAINT FK_CountryISO2 FOREIGN KEY (CountryISO2) REFERENCES Data.Country(CountryISO2);

INSERT INTO Reference.MarketingInformation (CountryISO2)
SELECT Country
FROM Reference.MarketingInformation;

ALTER TABLE Reference.MarketingInformation
DROP COLUMN Country;

ALTER TABLE Reference.MarketingInformation
ADD SpendCapacityID Udt.SurrogateKeyInt IDENTITY(1,1);

ALTER TABLE Reference.MarketingInformation
DROP COLUMN SpendCapacity;
END;

GO

-- Create table to remove non-key dependency
CREATE PROCEDURE MotorSales.CreateSpendCapacity
AS
BEGIN
    SET NOCOUNT ON;

IF NOT EXISTS (SELECT * FROM sys.types WHERE name = 'CapacityCategoryType' AND SCHEMA_NAME(schema_id) = 'Udt') --create new UDT
		CREATE TYPE Udt.CapacityCategoryType FROM NVARCHAR(150);

CREATE TABLE MotorSales.SpendCapacity(
    SpendCapacityID Udt.SurrogateKeyInt IDENTITY(1,1), -- create column for primary key
    SpendCapacityCategory Udt.CapacityCategoryType
)

INSERT INTO MotorSales.SpendCapacity(SpendCapacityCategory) --fill column from other table
SELECT SpendCapacity
FROM Reference.MarketingInformation;
END;

GO

-- Normalize SalesBudget
CREATE PROCEDURE SalesBudget.NormalizeSalesBudget
AS 
BEGIN
    SET NOCOUNT ON;

ALTER TABLE Reference.SalesBudget
ADD BudgetAreaID Udt.SurrogateKeyInt IDENTITY(1,1) --create new column for primary and foreign key

ALTER TABLE Reference.SalesBudget
ADD CONSTRAINT PK_BudgetAreaID PRIMARY KEY (BudgetAreaID)

ALTER TABLE Reference.SalesBudget
ADD CONSTRAINT FK_BudgetAreaID FOREIGN KEY(BudgetAreaID) REFERENCES SalesBudget.SalesBudgetArea(BudgetAreaID)

ALTER TABLE Reference.SalesBudget --remove non-key dependency
DROP COLUMN BudgetArea

END;

GO


-- Create SalesBudgetArea to remove non-key dependency
CREATE PROCEDURE SalesBudget.CreateSalesBudgetArea
AS
BEGIN
    SET NOCOUNT ON;

CREATE TABLE SalesBudget.SalesBudgetArea(
    BudgetAreaID Udt.SurrogateKeyInt IDENTITY(1,1), --create column for primary key
    BudgetArea Udt.CountryName
)

ALTER TABLE SalesBudget.SalesBudgetArea
ADD CONSTRAINT PK_BudgetAreaID PRIMARY KEY(BudgetAreaID);

INSERT INTO SalesBudget.SalesBudgetArea(BudgetArea) --fill column from another table
SELECT BudgetArea
FROM Reference.SalesBudgets

END;
GO


-- Normalize SalesCategory
CREATE PROCEDURE MotorSales.NormalizeSalesCategory
AS
BEGIN
    SET NOCOUNT ON;

ALTER TABLE Reference.SalesCategory
ADD SalesCatagoryID Udt.SurrogateKeyInt IDENTITY(1,1); -- create new column for the primary key

ALTER TABLE Reference.SalesCategory
ADD CONSTRAINT PK_SalesCatagoryID PRIMARY KEY(SalesCatagoryID)

END;
GO


