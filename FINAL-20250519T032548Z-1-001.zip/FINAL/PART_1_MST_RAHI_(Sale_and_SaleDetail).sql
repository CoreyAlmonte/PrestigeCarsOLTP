USE [PrestigeCars];
GO

/*
===============================================================================
  PROCEDURE:     MotorSales.usp_normalizeSale
===============================================================================
  AUTHOR(S):     MST Rahi    
                 Corey Almonte  
  CREATED:       2025-05-18
  VERSION:       3.0

  DESCRIPTION:
    Alters [MotorSales].[Sale] to conform to the UML-compliant schema:
      - Uses professor-defined UDTs only
      - Ensures NOT NULL on all columns
      - Adds DEFAULT and CHECK constraints
      - Adds UNIQUE NONCLUSTERED index on InvoiceNumber
      - Populates data from [Data].[FlattenedTable] with no WHERE clause

  MODIFICATION HISTORY:
  ------------------------------------------------------------------------------
  DATE        AUTHOR(S)         DESCRIPTION
  ----------  ----------------  -----------------------------------------------
  2025-05-09  MST Rahi      Initial creation based on UML diagram  
  2025-05-17  MST Rahi      Underwent professor code review  
  2025-05-18  MST Rahi      Split from usp_normalizePair2 into this version  
===============================================================================
*/

CREATE OR ALTER PROCEDURE MotorSales.usp_normalizeSale
AS
BEGIN
    SET NOCOUNT ON;

    --------------------------------------------------------------------------------
    -- ALTER TABLE MotorSales.Sale
    --------------------------------------------------------------------------------
    ALTER TABLE MotorSales.Sale
    ALTER COLUMN InvoiceNumber UDT_InvoiceNumber NOT NULL;
    
    ALTER TABLE MotorSales.Sale
    ALTER COLUMN TotalSalePrice UDT_TotalSalePrice NOT NULL;
    
    ALTER TABLE MotorSales.Sale
    ALTER COLUMN SaleDate UDT_SaleDate NOT NULL;
    
    ALTER TABLE MotorSales.Sale
    ALTER COLUMN CustomerID UDT_CustomerID NOT NULL;

    ALTER TABLE MotorSales.Sale
    ADD CONSTRAINT DF_InvoiceNumber_Default DEFAULT 'UNSPECIFIED' FOR InvoiceNumber,
        CONSTRAINT DF_TotalSalePrice_Default DEFAULT 0.00 FOR TotalSalePrice,
        CONSTRAINT DF_SaleDate_Default DEFAULT '1900-01-01' FOR SaleDate,
        CONSTRAINT CHK_TotalSalePrice_NonNegative CHECK (TotalSalePrice >= 0);

    --------------------------------------------------------------------------------
    -- CREATE UNIQUE NONCLUSTERED INDEX on InvoiceNumber
    --------------------------------------------------------------------------------
    IF NOT EXISTS (
        SELECT * FROM sys.indexes 
        WHERE name = 'IX_Sale_InvoiceNumber'
          AND object_id = OBJECT_ID('MotorSales.Sale')
    )
    BEGIN
        CREATE UNIQUE NONCLUSTERED INDEX IX_Sale_InvoiceNumber
        ON MotorSales.Sale (InvoiceNumber);
    END;

    --------------------------------------------------------------------------------
    -- INSERT DATA INTO MotorSales.Sale
    --------------------------------------------------------------------------------
    INSERT INTO MotorSales.Sale (
        InvoiceNumber, TotalSalePrice, SaleDate, CustomerID
    )
    SELECT DISTINCT
        f.InvoiceNumber,
        f.TotalSalePrice,
        CAST(f.SaleDate AS DATE),
        f.CustomerID
    FROM Data.FlattenedTable f;

END;
GO


USE [PrestigeCars];
GO

/*
===============================================================================
  PROCEDURE:     MotorSales.usp_normalizeSaleDetail
===============================================================================
  AUTHOR(S):     MST Rahi 
                 Corey Almonte  
  CREATED:       2025-05-18
  VERSION:       3.0

  DESCRIPTION:
    Alters [MotorSales].[SaleDetail] to conform to the UML-compliant schema:
      - Uses only professor-defined UDTs
      - Enforces NOT NULL constraints
      - Adds DEFAULT and CHECK constraints
      - Inserts data from [Data].[FlattenedTable] (no WHERE clause)

  MODIFICATION HISTORY:
  ------------------------------------------------------------------------------
  DATE        AUTHOR(S)         DESCRIPTION
  ----------  ----------------  -----------------------------------------------
  2025-05-09  MST Rahi      Initial creation based on UML diagram  
  2025-05-17  MST Rahi      Underwent professor code review  
  2025-05-18  MST Rahi      Split from usp_normalizePair2 into this version  
===============================================================================
*/

CREATE OR ALTER PROCEDURE MotorSales.usp_normalizeSaleDetail
AS
BEGIN
    SET NOCOUNT ON;

    --------------------------------------------------------------------------------
    -- ALTER TABLE MotorSales.SaleDetail
    --------------------------------------------------------------------------------
    ALTER TABLE MotorSales.SaleDetail
    ALTER COLUMN SaleID UDT_SaleID NOT NULL;

    ALTER TABLE MotorSales.SaleDetail
    ALTER COLUMN LineItemNumber UDT_LineItemNumber NOT NULL;

    ALTER TABLE MotorSales.SaleDetail
    ALTER COLUMN SalePrice UDT_SalePrice NOT NULL;

    ALTER TABLE MotorSales.SaleDetail
    ALTER COLUMN LineItemDiscount UDT_LineItemDiscount NOT NULL;

    ALTER TABLE MotorSales.SaleDetail
    ALTER COLUMN StockID dbo.UDT_StockID NOT NULL;

    ALTER TABLE MotorSales.SaleDetail
    ADD CONSTRAINT DF_LineItemNumber_Default DEFAULT 1 FOR LineItemNumber,
        CONSTRAINT CHK_SalePrice_NonNegative CHECK (SalePrice >= 0),
        CONSTRAINT CHK_LineItemDiscount_NonNegative CHECK (LineItemDiscount >= 0);

    --------------------------------------------------------------------------------
    -- INSERT DATA INTO MotorSales.SaleDetail
    --------------------------------------------------------------------------------
    INSERT INTO MotorSales.SaleDetail (
        SaleID, LineItemNumber, SalePrice, LineItemDiscount, StockID
    )
    SELECT
        s.SaleID,
        f.LineItemNumber,
        f.SalePrice,
        f.LineItemDiscount,
        st.StockID
    FROM Data.FlattenedTable f
    JOIN MotorSales.Sale s ON f.InvoiceNumber = s.InvoiceNumber
    JOIN MotorSales.Stock st ON f.StockCode = st.StockCode;

END;
GO