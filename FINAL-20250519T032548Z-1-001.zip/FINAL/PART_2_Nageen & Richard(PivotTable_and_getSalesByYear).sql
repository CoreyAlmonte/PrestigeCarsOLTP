USE PrestigeCars;
GO

/*
===============================================================================
  VIEW:         [Data].[PivotTable]
===============================================================================
  AUTHOR(S):    Nageen Saira, Richard Garnica, Corey Almonte
  CREATED:      2025-05-18
  VERSION:      1.1

  DESCRIPTION:
    Replaces the old PivotTable physical table with a proper view that pivots
    yearly TotalSalePrice values from the [Data].[Sales] table using the PIVOT operator.

    Each column in the output represents aggregated sales totals per year.
    This enables year-over-year comparison for analytical dashboards.

  OUTPUT COLUMNS:
    - SaleDate               UDT_DateYYYYMMDD
    - [2015]                 UDT_TotalSalePrice
    - [2016]                 UDT_TotalSalePrice
    - [2017]                 UDT_TotalSalePrice
    - [2018]                 UDT_TotalSalePrice

  MODIFICATION HISTORY:
  ------------------------------------------------------------------------------
  DATE        AUTHOR(S)                         DESCRIPTION
  ----------  --------------------------------  ----------------------------------
  2025-05-18  Nageen Saira, Richard Garnica, Corey Almonte   Replaced table with view using PIVOT
===============================================================================
*/

-- Drop the old table if it still exists
DROP TABLE IF EXISTS Data.PivotTable;
GO

-- Recreate PivotTable as a View
CREATE VIEW Data.PivotTable
AS
SELECT *
FROM (
    SELECT
        CAST(SaleDate AS DATE) AS SaleDate,
        YEAR(SaleDate) AS SaleYear,
        TotalSalePrice
    FROM Data.Sales
) AS src
PIVOT (
    SUM(TotalSalePrice)
    FOR SaleYear IN ([2015], [2016], [2017], [2018])
) AS pvt;
GO


USE PrestigeCars;
GO

/*
===============================================================================
  FUNCTION:     [Output].[fn_getSalesByYear]
===============================================================================
  AUTHOR(S):    Nageen Saira, Richard Garnica, Corey Almonte
  CREATED:      2025-05-18
  VERSION:      1.1

  DESCRIPTION:
    Returns all sales for a given year from [Data].[Sales],
    simulating the behavior of year-specific tables like Sales2015.

  PARAMETERS:
    - @InputYear: INT

  OUTPUT COLUMNS:
    - SalesID, CustomerID, InvoiceNumber, TotalSalePrice, SaleDate
===============================================================================
*/
CREATE OR ALTER FUNCTION Output.fn_getSalesByYear (
    @InputYear INT
)
RETURNS TABLE
AS
RETURN (
    SELECT
        SalesID,
        CustomerID,
        InvoiceNumber,
        TotalSalePrice,
        SaleDate
    FROM Data.Sales
    WHERE YEAR(SaleDate) = @InputYear
);
GO


USE PrestigeCars;
GO

/*
===============================================================================
  VIEW:         [Data].[PivotTable]
===============================================================================
  AUTHOR(S):    Nageen Saira, Richard Garnica, Corey Almonte
  CREATED:      2025-05-18
  VERSION:      1.1

  DESCRIPTION:
    Creates a pivot table that summarizes TotalSalePrice by SaleDate for each year.
===============================================================================
*/
CREATE OR ALTER VIEW [Data].[PivotTable]
AS
SELECT *
FROM (
    SELECT
        CAST(SaleDate AS DATE) AS SaleDate,
        YEAR(SaleDate) AS SaleYear,
        TotalSalePrice
    FROM Data.Sales
) AS src
PIVOT (
    SUM(TotalSalePrice)
    FOR SaleYear IN ([2015], [2016], [2017], [2018])
) AS pvt;
GO