USE PrestigeCars
GO

/*
================================================================================
  PROCEDURES:   [MotorSales].[FixCustomerTable]
                [MotorSales].[CreateCustomerLocationTable]
                [MotorSales].[CreateLocationTable]
================================================================================
  AUTHOR:      Ketan Persaud
  DATE:        5/7/2025
  VERSION:     1.0
  DESCRIPTION: 
  First Procedure alters the customer column defining a primary key on customerID, filling in the trucated columns from the flatten database table and changes the data types to a UDT
  The Second Procedure Creates a table for the customer location information. This information is created with the identitiy function.
  The Third Procedure Creates a table for the information on locations. This contains Address1, Address2, Town, PostalCode, and CountryISO2
  
  
  PARAMETERS:
  None
  
  USAGE EXAMPLE:
  EXEC [MotorSales].[FixCustomerTable]
  EXEC [MotorSales].[CreateCustomerLocationTable]
  EXEC [MotorSales].[CreateLocationTable]
  
  RESULT:
  Three stored procedures that normalizes the Customer Table
  
  MODIFICATIONS:
  DATE        AUTHOR(S)							DESCRIPTION
  ----------  ---------------					----------------------------------------------------
  5/7/2025    Ketan Persaud                     Initial creation
================================================================================
**/

GO
-- Fills the Customer Table and changes the data type into a UDT and creates Primary Key on CustomerID
CREATE PROCEDURE [MotorSales].[FixCustomerTable]
AS
BEGIN
    SET NOCOUNT ON;

ALTER TABLE Data.Customer
ALTER COLUMN CustomerID Udt.SurrogateKeyInt;

ALTER TABLE Data.Customer
ADD Constraint PK_CustomerID
PRIMARY KEY (CustomerID)

INSERT INTO Data.Customer(CustomerName , IsReseller, IsCreditRisk)
SELECT CustomerName , IsReseller, IsCreditRisk 
FROM Data.FlattenedTable

END;
GO
-- Creates a new table for the customer location
CREATE PROCEDURE [MotorSales].[CreateCustomerLocationTable]
AS
BEGIN
    SET NOCOUNT ON;

Create TABLE Data.CustomerLocation(
CustomerID Udt.SurrogateKeyInt IDENTITY(1,1) NOT NULL, 
LocationID Udt.SurrogateKeyInt IDENTITY(1,1) NOT NULL,

CONSTRAINT PK_CustomerID 
PRIMARY KEY (CustomerID),


)

END;
GO

-- Creates a new table for locations
CREATE PROCEDURE [MotorSales].[CreateLocationTable]
AS
BEGIN
    SET NOCOUNT ON;

Create TABLE Data.Location(
    LocationID  Udt.SurrogateKeyInt IDENTITY(1,1),
    Address1 Udt.AddressType,
    Address2 Udt.AddressType,
    Town Udt.TownType,
    PostalCode Udt.PostalCodeType,
    CountryISO2 Udt.CountryCode,
    CONSTRAINT PK_LocationID PRIMARY KEY (LocationID)



);
ALTER TABLE data.location
ADD CONSTRAINT DF_Address1_Default DEFAULT 'UNSPECIFIED' FOR Address1;

ALTER TABLE data.location
ADD CONSTRAINT DF_Address2_Default DEFAULT 'UNSPECIFIED' FOR Address2;

ALTER TABLE data.location
ADD CONSTRAINT DF_Town_Default DEFAULT 'UNSPECIFIED' FOR Town;

ALTER TABLE data.location
ADD CONSTRAINT DF_PostalCode_Default DEFAULT 'UNSPECIFIED' FOR PostalCode;

ALTER TABLE data.location
ADD CONSTRAINT DF_Country_Default DEFAULT 'UNSPECIFIED' FOR CountryISO2;



INSERT INTO Data.Location(Address1 , Address2, Town, PostalCode, CountryISO2 )
SELECT Address1 , Address2, Town, PostalCode, CountryISO2 
FROM Data.FlattenedTable;

END;
GO





